import os
import sys
import argparse

def parseArgument():
	dir_tmp = os.getcwd()
	version = '1.0'
	usageTmp = '\r{}\n\
##                                                                                            ##\n\
##      APEDE (Evaluation the data quality of the five experiments in CPTAC assay portal)     ##\n\
##                                                                                            ##\n\
##      last change: 09/26/2018                                                               ##\n\
##                                                                                            ##\n\
##                                                                                            ##\n\
################################################################################################\n\
\n'.format('################################################################################################'.ljust(len('usage:')))
	#create top-level parser
	usage = usageTmp+'Usage: %(prog)s <command> [<args>]\n\
The three modules to input data for APEDE are:\n\
   skylinefile        sky.zip file which researchers initially uploaded into panoramaweb.org\n\
                 Type "APEDE query -h" to show the help message of this funtion\n\
   panoramafile        .tsv file saved after querying panoramaweb.org from the specific URL\n\
                 Type "APEDE panoramafile -h" to show the help message of this funtion\n\
   query        peptide, protein, precursor_charge and dataset_path are needed\n\
                 Type "APEDE query -h" to show the help message of this funtion\n'
	parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter, description=usage, usage=argparse.SUPPRESS)
	subparsers = parser.add_subparsers(help='sub-command help')
	#create the parser for the 'skylinefile' command
	usage1 = usageTmp+'Usage: APEDE skylinefile [-h] [<args>]\n\nExample:\nAPEDE skylinefile -ps C:\Program Files\Skyline -f test.sky.zip -e exp1\n'
	parser_1 = subparsers.add_parser('skylinefile', usage = usage1)
	parser_1.add_argument('-ps', required=True, dest='SkylineCmdBinary', metavar='<dir required>', help="the path to SkylineCmd.exe in the system")
	parser_1.add_argument('-f', required=True, dest='input_file', metavar='file <required>', help='the *.sky.zip file which is initially uploaded into panoramaweb.org by researchers')
	parser_1.add_argument('-e', required=True, dest='experiment_type', metavar='string <required>', help='the experiment type. Choose one from Options: exp1 , exp2 , exp3 , exp4, exp5')
	parser_1.add_argument('-o', default=dir_tmp, dest='output_dir', metavar='<dir>', help='the directory of the outputs (default: current directory)')
	parser_1.add_argument('--version', action='version', version='%s'%(version))

	#create the parser for the 'panoramafile' command
	usage2 = usageTmp+'Usage: APEDE panoramafile [-h] [<args>]\n\nExample:\nAPEDE panoramafile -f ValidationSamples-JHU_Pandey-CellLysate_LumosOrbitrap_directPRM.tsv -e exp1\n'
	parser_2 = subparsers.add_parser('panoramafile', usage = usage1)
	parser_2.add_argument('-f', required=True, dest='input_file', metavar='file <required>', help='the *.tsv file which is downloaded after querying panoramaweb.org from the specific URL')
	parser_2.add_argument('-e', required=True, dest='experiment_type', metavar='string <required>', help='the experiment type. Choose one from Options: exp1 , exp2 , exp3 , exp4, exp5')
	parser_2.add_argument('-o', default=dir_tmp, dest='output_dir', metavar='<dir>', help='the directory of the outputs (default: current directory)')
	parser_2.add_argument('--version', action='version', version='%s'%(version))

	return parser.parse_args()
