#!/usr/bin/env python

# CHANGE LOG:
# 

__author__ = 'Yin Lu'
__copyright__ = 'Copyright 2018, ESAC, Inc'
__credits__ = ['Yin Lu']
__license__ = 'GPL'
__version__ = '2.0'
__maintainer__ = 'Yin Lu'
__email__ = 'yin.lu@esacinc.com'

# System imports
import os
import sys
import argparse
import time
import warnings
from distutils.spawn import find_executable
from zipfile import ZipFile

# Fuction modules imports
from parseArgument import *
from qcAnalysis import *


# If infFile is mapped.csv, the testMode will be turned on automatically or manually.
# test mode will call cluster_analysis.py.
# testMode = True

def main():
	warnings.filterwarnings("ignore")
	# Parse the input arguments
	args = parseArgument()

	# Preprocess the inout arguments
	experiment_type = args.experiment_type
	experiment_type = experiment_type.lower()
	skyrTempsDir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'skyrTemps')
	rScriptsDir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'rScripts')
	if experiment_type == 'exp1':
		skyrTemp = os.path.join(skyrTempsDir, "experiment1.skyr")
		rScript = os.path.join(rScriptsDir, "experiment1.R")
		reportName="experiment1"
	elif experiment_type == 'exp2':
		skyrTemp = os.path.join(skyrTempsDir, "experiment2.skyr")
		rScript = os.path.join(rScriptsDir, "experiment2.R")
		reportName="experiment2"
	elif experiment_type == 'exp3':
		skyrTemp = os.path.join(skyrTempsDir, "experiment3.skyr")
		rScript = os.path.join(rScriptsDir, "experiment3.R")
		reportName="experiment3"
	elif experiment_type == 'exp4':
		skyrTemp = os.path.join(skyrTempsDir, "experiment4.skyr")
		rScript = os.path.join(rScriptsDir, "experiment4.R")
		reportName="experiment4"
	elif experiment_type == 'exp5':
		skyrTemp = os.path.join(skyrTempsDir, "experiment5.skyr")
		rScript = os.path.join(rScriptsDir, "experiment5.R")
		reportName="experiment5"
	else:
		print >> sys.stderr, "Invalid experiment type. Please check it."
		sys.exit(1)
	
	dir = os.path.abspath(args.output_dir)
	# set the outout directory
	tStamp = time.strftime('%Y-%m-%d_%H-%M-%S',time.localtime(time.time()))
	outputdir = os.path.join(dir, experiment_type+'.'+tStamp)
	os.mkdir(outputdir)

	if sys.argv[1] == 'skylinefile':
		SkylineCmdBinary = args.SkylineCmdBinary
		# Check the binaries directory to make sure it can work
		executable = find_executable(os.path.join(SkylineCmdBinary, 'SkylineCmd.exe'))
		if not executable:
			print >> sys.stderr, "SkylineCmd.exe can't be found in %s. Please check it."%(SkylineCmdBinary)
			sys.exit(1)
		input_file_list = os.path.abspath(args.input_file_list)
		input_dir = os.path.abspath(args.input_dir)
		# judge the input type: multiple *.sky.zip files or a directory.
		print input_file_list
		print input_dir
		
		"""
		
		# Check the format of input_file which should be *.sky.zip
		if input_file[-8:] != ".sky.zip":
			print >> sys.stderr, "The format of %s is incorrect. Please check it to make sure its suffix is .sky.zip"
		input_file_basename = os.path.basename(input_file)
		# Unzip the input_file
		zf = ZipFile(input_file, 'r')
		zf.extractall(outputdir)
		zf.close()
		input_file_sky = os.path.join(outputdir, input_file_basename[:-8]+'.sky')
		# Parse and transform the input_file_sky into report file based on the specific skyline document report template
		output_file = os.path.join(outputdir, input_file_basename[:-8]+'.tsv')
		# Run SkylineCmd.exe toward the sky document file and export a *.tsv report file
		os.system("%s --timestamp --in=%s --report-file=%s --report-format=TSV --report-name=%s --report-add=%s --report-conflict-resolution=overwrite --report-invariant"%(SkylineCmdBinary, input_file_sky, output_file, reportName, skyrTemp))
		# QC the output_file for the first step
		"""

if __name__ == '__main__':
	main()
