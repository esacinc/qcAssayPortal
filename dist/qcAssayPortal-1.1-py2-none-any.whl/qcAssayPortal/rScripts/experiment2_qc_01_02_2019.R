# This sample code is modified based on esac-panorama-master\AssayPortal\resources\reports\schemas\targetedms\QCAnalysisQuery\web_portal_QC.r

# returns the query data in tab-separated values format, which LabKey then
# renders as HTML. Replace this code with your R script. See the Help tab for more details.
#write.table(labkey.data, file = "${tsvout:tsvfile}", sep = "\t", qmethod = "double", col.names=NA)

# UPDATE: return top 3 plots plus sum of ions plot (Sept 2014)

# UPDATE: new sort to get top 3 plots (March 2016)

# UPDATE: in cases where there are medium labeled peptides instead of light labeled peptides, 
#   'medium' Isotope Label is converted to 'light' Isotope Label to calculate variable/constant ratios (April 2016)
# For a reverse curve: H/L = H/M. For a forward curve: L/H = M/H.

# UPDATE: convert all sample_group values to Lo, Med, Hi based on first character (L, M, H) of sample_group (April 2016)

#library(Cairo) # need for producing PNG image using Panoramax
suppressWarnings(suppressMessages(library(Rlabkey)))
suppressWarnings(suppressMessages(library(Cairo)))
suppressWarnings(suppressMessages(library(stringr)))

# ***** plot_QC function *****
plot_QC <- function(plot_fragment_ion_results, input_peptide_sequence, current_ion, days) {


  if (current_ion == 'all'){

      current_ion <- 'sum of ions'
  }


  plot_title <- paste(input_peptide_sequence, current_ion, sep='\n')

  min_calculated_area_ratio <- min(plot_fragment_ion_results$calculated_area_ratio)
  max_calculated_area_ratio <- max(plot_fragment_ion_results$calculated_area_ratio)



  # Expand right side of clipping rect to make room for the legend
  par(xpd=TRUE, mar=par()$mar+c(0,0,0,4))

  # bty="L",

  plot(plot_fragment_ion_results$day, plot_fragment_ion_results$calculated_area_ratio, log="y", yaxt="n", col=ifelse(plot_fragment_ion_results$sample_group=='Hi', 'red',
                                                                                                                     ifelse(plot_fragment_ion_results$sample_group=='Med', 'blue', 'green')),

       pch=ifelse(plot_fragment_ion_results$replicate==1 , 1,
                  ifelse(plot_fragment_ion_results$replicate==2 , 0,
                         ifelse(plot_fragment_ion_results$replicate==3 , 2,
                                ifelse(plot_fragment_ion_results$replicate==4 , 5,
                                       ifelse(plot_fragment_ion_results$replicate==5 , 6,
                                4))))),

       cex=2, lwd=1, main=plot_title, xlab="Time (day)", ylab="Measured (area ratio) [log-scale]", cex.lab=1.75, cex.axis=1.75)


  #x_axis_values <- c(1,2,3,4,5)
  x_axis_values <- days

  #y_axis_values <- c(0.01,0.1,1,10,100,format(max_calculated_measured_concentration,digits=3))
  y_axis_values <- c(format(min_calculated_area_ratio,digits=3),format(median(plot_fragment_ion_results$calculated_area_ratio),digits=3),format(max_calculated_area_ratio,digits=3))




  #format(y_axis_values,scientific=FALSE,digits=4)

  axis(2, y_axis_values, labels=format(y_axis_values,scientific=FALSE)) # draw y axis with required labels

  #par(xpd=TRUE)
  #legend(x=4,y=max_calculated_area_ratio,legend=c("rep1","rep2","rep3","repX","Hi","Med","Lo"),pch=c(1,0,2,4,18,18,18), col=c("black","black","black","black","red","blue","green"), bty="n")

  legend(x=max(days)+0.2,y=max_calculated_area_ratio,legend=c("rep1","rep2","rep3","rep4","rep5","Hi","Med","Lo"),pch=c(1,0,2,5,6,18,18,18), col=c("black","black","black","black","black","red","blue","green"), cex=1, bty="n")

  # Restore default clipping rect
  par(mar=c(5, 4, 4, 2) + 0.1)



} # end plot_QC function

#
# To install:
#
#   install.packages("Rlabkey", repos="http://cran.fhcrc.org")
#
# See: https://www.labkey.org/home/Documentation/wiki-page.view?name=rAPI
# 
# Set up login information, $HOME/.netrc with
#
#   machine panoramaweb.org
#   login XXXXX
#   password YYYYY
#
# File must be set to only allow the user to read/write: chmod 600 $HOME/.netrc
#
# See: https://www.labkey.org/home/Documentation/wiki-page.view?name=netrc
#
# Execution example:
#
#    Rscript web_portal_QC.r "CPTAC_TEST/Broad_Carr_CellLysate_TSQQuantiva_IMACMRM_TEST" \
#                             AURKA 'TT[+80.0]LC[+57.0]GTLDYLPPEMIEGR' '3' 'forward'   
#

identify_uniProtKB_entryID  <- function(x) {
    # the extract uniProtKB_entryID from the protein name
    if (grepl('\\|', x)) {
        tmp <- strsplit(x, split = '\\|')
        uniProtKB_entryID_tmp <- tmp[[1]][2]
        # judge whether uniProtKB_entryID is a legal uniProtKB entry ID based on its pattern using regular expression. Please refer to https://www.uniprot.org/help/accession_numbers
        if (str_detect(uniProtKB_entryID_tmp, "[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9]([A-Z][A-Z0-9]{2}[0-9]){1,2}")) {
            uniProtKB_entryID <- uniProtKB_entryID_tmp
        } else {
            uniProtKB_entryID <- x
        }
    } else {
        uniProtKB_entryID <- x
    }
    uniProtKB_entryID
}

args <- commandArgs(trailingOnly = TRUE)
dataset_path <- args[1]
fileList_path <- args[2]
plot_output <- args[3]
plot_output_dir <- args[4]


#dataset_path <- "normal_data.tsv"
#fileList_path <- "file_namelist_IS.tsv"
#plot_output <- "True"
#plot_output_dir <- "D:\\Skyline_analysis\\qcAssayPortal\\qcAssayPortal\\src\\qcAssayPortal\\rScripts\\test\\4"



if (plot_output == 'True') {
    plot_output <- TRUE
} else {
    plot_output <- FALSE
}
cv_threshold <- 60.0


# load data from local table
QC_set_total <- read.table(file=dataset_path, header=TRUE, sep='\t')
fileDf <- read.table(file=fileList_path, header=TRUE, sep='\t')


thenames <- tolower(names(QC_set_total))
names(QC_set_total) <- thenames

#
# Now back to your regularly scheduled program
#

#column names in Panorama query:
#protein
#peptidemodifiedsequence
#isotopelabel
#precursorcharge
#productcharge
#fragmention
#area
#replicatename
#replicate
#concentration
#samplegroup
#dilutionfactor
#peptideconcentration
#id
#runid_folder

# sample row
#1 YARS.IPI00007074 VDAQFGGIDQR heavy 2 1 y6 3573011.0 GO_QCorig_Broad_1000ng_Interlab_092412_031 3 2 Med 1.0 2 22199 #66fba526-16af-1031-a003-


# Rename columns in QC_set_total dataframe (replace Panorama names with new names used by R script)
colnames(QC_set_total)[colnames(QC_set_total)=="skydocumentname"] <- "SkyDocumentName"
colnames(QC_set_total)[colnames(QC_set_total)=="proteinname"] <- "protein_name"
colnames(QC_set_total)[colnames(QC_set_total)=="peptidemodifiedsequence"] <- "peptide"
colnames(QC_set_total)[colnames(QC_set_total)=="isotopelabeltype"] <- "isotope_label_type"     # light, heavy
colnames(QC_set_total)[colnames(QC_set_total)=="precursorcharge"] <- "precursor_charge"
colnames(QC_set_total)[colnames(QC_set_total)=="productcharge"] <- "product_charge"
colnames(QC_set_total)[colnames(QC_set_total)=="fragmention"] <- "fragment_ion_only"
colnames(QC_set_total)[colnames(QC_set_total)=="area"] <- "area"
colnames(QC_set_total)[colnames(QC_set_total)=="replicatename"] <- "replicate_name"
colnames(QC_set_total)[colnames(QC_set_total)=="replicate"] <- "replicate"
colnames(QC_set_total)[colnames(QC_set_total)=="concentration"] <- "concentration"      # day
colnames(QC_set_total)[colnames(QC_set_total)=="samplegroup"] <- "sample_group"     # Lo, Med, Hi

QC_set_total$fragment_ion <- paste(QC_set_total[ ,'fragment_ion_only'], " (", QC_set_total[ ,'product_charge'], "+)", sep='' )


# Preprocess the columns in QC_set_total
# convert columns from character to numeric
QC_set_total[,'concentration'] <- as.numeric(as.character(QC_set_total[,'concentration']))
QC_set_total[,'replicate'] <- as.numeric(as.character(QC_set_total[,'replicate']))
QC_set_total[,'area'] <- as.numeric(as.character(QC_set_total[,'area']))

# remove factor version
QC_set_total[,'SkyDocumentName'] <- as.character(QC_set_total[,'SkyDocumentName'])
QC_set_total[,'protein_name'] <- as.character(QC_set_total[,'protein_name'])
QC_set_total[,'peptide'] <- as.character(QC_set_total[,'peptide'])
QC_set_total[,'precursor_charge'] <- as.character(QC_set_total[,'precursor_charge'])
QC_set_total[,'product_charge'] <- as.character(QC_set_total[,'product_charge'])
QC_set_total[,'isotope_label_type'] <- as.character(QC_set_total[,'isotope_label_type'])
QC_set_total[,'fragment_ion_only'] <- as.character(QC_set_total[,'fragment_ion_only'])
QC_set_total[,'replicate_name'] <- as.character(QC_set_total[,'replicate_name'])
QC_set_total[,'fragment_ion'] <- as.character(QC_set_total[,'fragment_ion'])
QC_set_total[,'sample_group'] <- as.character(QC_set_total[,'sample_group'])
QC_set_total[,'sample_group'] <- as.character(QC_set_total[,'sample_group'])

# convert all sample_group values to Lo, Med, Hi based on first character of sample_group
QC_set_total[toupper(substr(QC_set_total$sample_group, 1, 1))=="L","sample_group"] <- "Lo"
QC_set_total[toupper(substr(QC_set_total$sample_group, 1, 1))=="M","sample_group"] <- "Med"
QC_set_total[toupper(substr(QC_set_total$sample_group, 1, 1))=="H","sample_group"] <- "Hi"

#print(dim(QC_set_total))
#print(fileDf[, "SkyDocumentName"])

# Initialize an empty data.frame QC_set_filtered with the column names same as QC_set_total's.
QC_set_filtered = data.frame()
for (k in colnames(QC_set_total)) {
    QC_set_filtered[[k]]<-as.character()
}

# Traverse the SkyDocumentName in filefileDf
for (SkyDocumentName in as.character(fileDf[, "SkyDocumentName"])) {
    # Choose the specific SkyDocumentName from QC_set
    #print(SkyDocumentName)
    QC_set1 <- QC_set_total[QC_set_total$SkyDocumentName==SkyDocumentName, ]
    #print(dim(QC_set1))
    # Get a list of all peptides
    peptide_list <- unique(QC_set1[ , 'peptide'])
    for (input_peptide_sequence in peptide_list) {
        QC_set2 <- QC_set1[QC_set1$peptide==input_peptide_sequence, ]
        # Get a list of all precursor_charges
        precursor_charge_list <- unique(QC_set2[ , 'precursor_charge'])
        for (input_precursor_charge in precursor_charge_list) {
            QC_set3 <- QC_set2[QC_set2$precursor_charge==input_precursor_charge, ]
            # Get a list of all protein names, although usually one peptide with a specific precursor charge has only one protein.
            protein_list <- unique(QC_set3[ , 'protein_name'])
            protein_uniProtID_list <- sapply(protein_list, identify_uniProtKB_entryID, USE.NAMES=FALSE)
            for (indexLabel in 1:length(protein_list)) {
            #for (input_protein_name in protein_list) {
                input_protein_name <- protein_list[indexLabel]
                protein_uniProtID <- protein_uniProtID_list[indexLabel]
                # Choose the specific peptide with a specific precursor charge from a specific protein.
                QC_setTmp <- QC_set3[QC_set3$protein_name==input_protein_name, ]
                # Get a list of all unique fragment ions, unique days, unique sample groups (Lo, Med, Hi), unique replicates and unique isotope_label_type associated with current peptide
                fragment_ion_list <- unique(QC_setTmp[ , 'fragment_ion'])
                days <- sort(unique(QC_setTmp[ , 'concentration']))
                sample_groups <- sort(unique(QC_setTmp[ , 'sample_group']))
                replicates <- sort(unique(QC_setTmp[ , 'replicate']))
                isotope_label_types <- unique(QC_setTmp[ , 'isotope_label_type'])
                # *** for medium labeled peptides ***
                if(('light' %in% isotope_label_types) & ('medium' %in% isotope_label_types)) {
                    errorReason <- "Error: Both light and medium isotope labels found in the peptide with a specific charge"
                    errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(isotope_label_types, collapse = '|'), input_precursor_charge, sep='\t')
                    cat(errorInfor)
                    cat('\n')
                    next
                } else {
                    QC_setTmp$isotope_label_type[QC_setTmp$isotope_label_type == "medium"] <- "light"
                }
                # Traverse fragment_ion_list, days, sample_groups and replicates
                # to evaluate the fragment_ion under the specific combination of day, sample_group, and replicate.
                for (current_ion in fragment_ion_list) {
                    for (current_day in days) {
                        for (current_sample in sample_groups) {
                            for (current_rep in replicates) {
                                current_set <- QC_setTmp[QC_setTmp$fragment_ion==current_ion & QC_setTmp$concentration==current_day & QC_setTmp$sample_group==current_sample & QC_setTmp$replicate==current_rep, ]
                                state1 <- nrow(current_set[current_set$isotope_label_type=='light', ]) > 1
                                state2 <- nrow(current_set[current_set$isotope_label_type=='heavy', ]) > 1
                                current_isotope_label_types <- unique(current_set[ , 'isotope_label_type'])
                                # Get fragment_ion_only and product_charge from current_ion
                                strTmp <- strsplit(current_ion, " ")[[1]]
                                fragment_ion_only <- strTmp[1]
                                product_charge <- substr(strTmp[2], 2, nchar(strTmp[2])-2)
                                current_replicate_names <- unique(current_set[ , 'replicate_name'])
                                peptideConcentrations <- unique(current_set[ , 'peptideconcentration'])
                                current_days <- unique(current_set[ , 'concentration'])
                                current_sample_groups <- unique(current_set[ , 'sample_group'])
                                current_replicates <- unique(current_set[ , 'replicate'])
                                current_fragment_ion_lists <- unique(current_set[ , 'fragment_ion'])
                                # create a data.frame whose column is count of unique and 
                                # row are annotation parts including replicate_names, days, sample_groups, replicates,  fragment_ion_list
                                dfTmp <- data.frame(attibuteName=c('replicate_name', 'concentration', 'sample_group', 'replicate', 'fragment_ion'), uniqueCount=c(length(current_replicate_names), length(current_days), length(current_sample_groups), length(current_replicates), length(current_fragment_ion_lists)), items=c(paste(current_replicate_names, collapse='|'), paste(current_days, collapse='|'), paste(current_sample_groups, collapse='|'), paste(current_replicates, collapse='|'), paste(current_fragment_ion_lists, collapse='|')))
                                idList <- which(dfTmp$uniqueCount>1)
                                errorReasonTmp <- c()
                                for (idTmp in idList) {
                                    errorReasonTmp <- c(errorReasonTmp, paste(dfTmp$attibuteName[idTmp], '(', dfTmp$items[idTmp], ')', sep=''))
                                }
                                errorReasonTmp <- paste(errorReasonTmp, collapse='; ')
                                #errorInfor <- paste(paste(state1, state1, sep='_'), SkyDocumentName, input_protein_name, input_peptide_sequence, paste(current_isotope_label_types, collapse = '|'), input_precursor_charge, current_ion, '', '', current_rep, current_day, current_sample, sep='\t')
                                #print(errorInfor)
                                if (state1 & state2) {
                                    errorReason <- paste('Error: More than one light isotopes and more than one heavy isotopes due to multiple values in attributes: ', errorReasonTmp, sep='')
                                    errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(current_isotope_label_types, collapse = '|'), input_precursor_charge, product_charge, fragment_ion_only, '', paste(current_replicate_names, collapse = '|'), current_rep, current_day, current_sample, paste(peptideConcentrations, collapse = '|'), sep='\t')
                                    cat(errorInfor)
                                    cat('\n')
                                    next
                                }
                                if (state1) {
                                    errorReason <- paste('Error: More than one light isotopes due to multiple values in attributes: ', errorReasonTmp, sep='')
                                    errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(current_isotope_label_types, collapse = '|'), input_precursor_charge, product_charge, fragment_ion_only, '', paste(current_replicate_names, collapse = '|'), current_rep, current_day, current_sample, paste(peptideConcentrations, collapse = '|'), sep='\t')
                                    cat(errorInfor)
                                    cat('\n')
                                    next
                                }
                                if (state2) {
                                    errorReason <- paste('Error: More than one heavy isotopes due to multiple values in attributes: ', errorReasonTmp, sep='')
                                    errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(current_isotope_label_types, collapse = '|'), input_precursor_charge, product_charge, fragment_ion_only, '', paste(current_replicate_names, collapse = '|'), current_rep, current_day, current_sample, paste(peptideConcentrations, collapse = '|'), sep='\t')
                                    cat(errorInfor)
                                    cat('\n')
                                    next
                                }
                                # After QC the input_peptide_sequence with the specific input_precursor_charge from the specific input_protein_name in the SkyDocumentName,
                                # the current_set will be merged into QC_set_filtered.
                                #cat(dim(current_set))
                                #cat('\n')
                                QC_set_filtered <- rbind(QC_set_filtered, current_set)
                            }
                        }
                    }
                }
            }
        }
    }


}

#cat(dim(QC_set_filtered))
# plot the figures and generate the tables.
if (plot_output) {
    # Choose the specific peptide from QC_set
    # QC_set <- QC_set[QC_set$protein_name==input_protein_name & QC_set$peptide==input_peptide_sequence & QC_set$precursor_charge==paste(input_precursor_charge, '+', sep=''), ]
    
    # Write peptide information into output file.
    log_filename <- paste(plot_output_dir, "\\peptide_infor.tsv", sep='' )
    logdf <- data.frame(peptide=as.character(), precursorCharge=as.character(), uniProtKBID=as.character(), proteinName=as.character(), SkyDocumentName=as.character())
    for (SkyDocumentName in as.character(fileDf[, "SkyDocumentName"])) {
        QC_set_1 <- QC_set_filtered[QC_set_filtered$SkyDocumentName==SkyDocumentName, ]
        peptide_list <- unique(QC_set_1[ , 'peptide'])
        for (input_peptide_sequence in peptide_list) {
            QC_set_2 <- QC_set_1[QC_set_1$peptide==input_peptide_sequence, ]
            precursor_charge_list <- unique(QC_set_2[ , 'precursor_charge'])
            for (input_precursor_charge in precursor_charge_list) {
                QC_set_3 <- QC_set_2[QC_set_2$precursor_charge==input_precursor_charge, ]
                protein_list <- unique(QC_set_3[ , 'protein_name'])
                protein_uniProtID_list <- sapply(protein_list, identify_uniProtKB_entryID, USE.NAMES=FALSE)
                for (indexLabel in 1:length(protein_list)) {
                #for (input_protein_name in protein_list) {
                    input_protein_name <- protein_list[indexLabel]
                    protein_uniProtID <- protein_uniProtID_list[indexLabel]
                    QC_set <- QC_set_3[QC_set_3$protein_name==input_protein_name, ]
                    if (nrow(QC_set) >= 1) { 
                        logdfTmp <- data.frame(peptide=QC_set[1,]$peptide, precursorCharge=QC_set[1,]$precursor_charge, uniProtKBID=protein_uniProtID, proteinName=QC_set[1,]$protein_name, SkyDocumentName=QC_set[1,]$SkyDocumentName)
                        #print(logdfTmp)
                        logdf <- rbind(logdf, logdfTmp)
                    }

                    fragment_ion_list <- unique(QC_set[ , 'fragment_ion'])
                    days <- sort(unique(QC_set[ , 'concentration']))
                    sample_groups <- sort(unique(QC_set[ , 'sample_group']))
                    replicates <- sort(unique(QC_set[ , 'replicate']))
                    isotope_label_types <- unique(QC_set[ , 'isotope_label_type'])
                    
                    # capture the warning caused by the number of fragment ions 
                    if (length(fragment_ion_list) < 3) {
                        errorReason <- paste("Warning: the number of fragment ions is ",  length(fragment_ion_list), " < 3, the fragment ions is(are): ", paste(fragment_ion_list, collapse = ', '), sep="")
                        errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(isotope_label_types, collapse = '|'), input_precursor_charge, '', '', '', '', '', '', '', '', sep='\t')
                                    cat(errorInfor)
                                    cat('\n')
                    }
                    
                    for (curve_type in c('forward', 'reverse')) {
                        ion_category <- 'error'
                        sum_light_area <- 0
                        sum_heavy_area <- 0
                        theoretical_area <- 0
                        measured_area <- 0
                        fragment_ion_results <- data.frame()
                        now <- Sys.time()
                        # # ***** prepare file to print PNG images *****
                        # only plot top 3 ions plus one more for sum
                        image_frame_count <- 4
                        #CairoPNG(filename=paste(plot_output_dir, "\\", input_peptide_sequence, "_", input_precursor_charge, "_", gsub('\\|', '_', input_protein_name), "_", curve_type ,"_", trunc(as.numeric(now)), ".png", sep=""), width=image_frame_count*400, height=400, bg="white", units="px")
                        CairoPNG(filename=paste(plot_output_dir, "\\", input_peptide_sequence, "_", input_precursor_charge, "_", curve_type ,"_", trunc(as.numeric(now)), ".png", sep=""), width=image_frame_count*400, height=400, bg="white", units="px")
                        par(mfrow= c(1, image_frame_count))
                        
                        # Step 1:
                        # Traverse fragment_ion_list, days, sample_groups and replicates
                        # to evaluate the fragment_ion under the specific combination of day, sample_group, and replicate.
                        for (current_ion in fragment_ion_list) {
                            for (current_day in days) {
                                for (current_sample in sample_groups) {
                                    for (current_rep in replicates) {
                                        current_set_count <- 0
                                        light_area <- 0
                                        heavy_area <- 0
                                        theoretical_area <- 0
                                        measured_area <- 0
                                        calculated_area_ratio <- 0
                                        
                                        current_set <- QC_set[QC_set$fragment_ion==current_ion & QC_set$concentration==current_day & QC_set$sample_group==current_sample & QC_set$replicate==current_rep, ]
                                        current_set_count <- nrow(current_set)
                                        
                                        if (current_set_count == 2) {
                                            light_area <- current_set[current_set$isotope_label_type=='light', 'area' ]
                                            heavy_area <- current_set[current_set$isotope_label_type=='heavy', 'area' ]

                                            if(curve_type=='forward') {
                                                theoretical_area <- heavy_area
                                                measured_area <- light_area
                                            }
                                            else {
                                                theoretical_area <- light_area
                                                measured_area <- heavy_area
                                            }
                                            if(theoretical_area==0 | is.na(theoretical_area) | is.na(measured_area)){
                                                calculated_area_ratio = NA
                                            }
                                            else {
                                                calculated_area_ratio <- measured_area/theoretical_area
                                            }
                                            fragment_ion_results <-  rbind(fragment_ion_results, data.frame(Peptide = input_peptide_sequence, Protein_Name = input_protein_name, Precursor_Charge = input_precursor_charge,
                                                                                                          fragment_ion = current_ion, day = current_day, sample_group = current_sample, replicate = current_rep, light_area=light_area, heavy_area=heavy_area,
                                                                                                          theoretical_area=theoretical_area, measured_area=measured_area,
                                                                                                          calculated_area_ratio=calculated_area_ratio, ion_category='individual') )
                                        }
                                        else {
                                        }
                                    } # end current_rep
                                } # end current_sample
                            } # end current_day
                        }  # end current_ion
                        # Step 2: repeat calculations for sum of ions 
                        for (current_day in days) {
                            for (current_sample in sample_groups) {
                                for (current_rep in replicates) {
                                    sum_light_area <- 0
                                    sum_heavy_area <- 0
                                    skipped_count <- 0
                                    skip_current_sample <- 'true'

                                    sum_theoretical_area <- 0
                                    sum_measured_area <- 0
                                    for (current_ion in fragment_ion_list) {
                                        current_set_count <- 0
                                        calculated_area_ratio <- 0
                                        light_area <- 0
                                        heavy_area <- 0
                                        theoretical_area <- 0
                                        measured_area <- 0
                                        
                                        current_set <- QC_set[QC_set$fragment_ion==current_ion & QC_set$concentration==current_day & QC_set$sample_group==current_sample & QC_set$replicate==current_rep, ]
                                        
                                        current_set_count <- nrow(current_set)
                                        
                                        if (current_set_count == 2) {
                                            light_area <- current_set[current_set$isotope_label_type=='light', 'area' ]
                                            heavy_area <- current_set[current_set$isotope_label_type=='heavy', 'area' ]
                                            if(curve_type=='forward'){
                                              theoretical_area <- heavy_area
                                              measured_area <- light_area
                                            }
                                            else {
                                              theoretical_area <- light_area
                                              measured_area <- heavy_area
                                            }

                                            add_to_sum <- 'false'

                                            if(theoretical_area==0 | is.na(theoretical_area) | is.na(measured_area)){
                                              skipped_count <- skipped_count + 1
                                            }
                                            else {
                                              sum_theoretical_area <- sum_theoretical_area + theoretical_area
                                              sum_measured_area <- sum_measured_area + measured_area

                                              sum_light_area <- sum_light_area + light_area
                                              sum_heavy_area <- sum_heavy_area + heavy_area

                                              add_to_sum <- 'true'
                                            }
                                            skip_current_sample <- 'false'
                                        } 
                                        else {
                                        }
                                    }
                                    
                                    if (skip_current_sample=='false'){
                                        if(sum_theoretical_area==0){
                                          calculated_area_ratio <- NA
                                        }
                                        else {
                                          calculated_area_ratio <- sum_measured_area/sum_theoretical_area
                                        }
                                        fragment_ion_results <-  rbind(fragment_ion_results, data.frame(Peptide = input_peptide_sequence, Protein_Name = input_protein_name, Precursor_Charge = input_precursor_charge,
                                                                                                        fragment_ion = 'all', day = current_day, sample_group = current_sample, replicate = current_rep, light_area=sum_light_area, heavy_area=sum_heavy_area,
                                                                                                        theoretical_area=sum_theoretical_area, measured_area=sum_measured_area,
                                                                                                        calculated_area_ratio=calculated_area_ratio, ion_category='all') )
                                    }
                                } # end current_rep
                            } # end current_sample
                        } # end current_day
                        # Step 3:
                        # ***** calculate CV (Coefficient of Variation) *****
                        LoMedHi <- c('Lo', 'Med', 'Hi')
                        ions <- c(fragment_ion_list, 'all')
                        # make CV summary data frame
                        CV_results <- data.frame()
                        for (current_ion in ions) {
                          # define columns (make row for each fragment ion)
                            CV_results <-  rbind(CV_results, data.frame(fragment_ion=current_ion, low_intra_CV=NA, med_intra_CV=NA, high_intra_CV=NA,
                                                                      low_inter_CV=NA, med_inter_CV=NA, high_inter_CV=NA,
                                                                      low_total_CV=NA, med_total_CV=NA, high_total_CV=NA,
                                                                      low_count=NA, med_count=NA, high_count=NA))
                        }
                        # *** intra-assay CV ***
                        for (current_ion in ions) {
                            for (current_LoMedHi in LoMedHi) {
                                avg_intra_assay_CV <-0
                                individual_intra_assay_CVs <- c()
                                for (current_day in days) {
                                    #for (current_rep in replicates) {
                                    current_set <- fragment_ion_results[fragment_ion_results$fragment_ion==current_ion & fragment_ion_results$day==current_day & fragment_ion_results$sample_group==current_LoMedHi, ]
                                    
                                    # remove rows with a value of NA for calculated_area_ratio
                                    current_set <- current_set[complete.cases(current_set[ , 'calculated_area_ratio' ]),]
                                    
                                    if (nrow(current_set) <= 1 ){
                                        percent_CV <- NA
                                    }
                                    else{
                                        percent_CV <- (sd(current_set$calculated_area_ratio))/(mean(current_set$calculated_area_ratio)) * 100
                                        individual_intra_assay_CVs <- c(individual_intra_assay_CVs, percent_CV)
                                    }
                                    #  } # end current_rep
                                } # end current_day

                                if (length(individual_intra_assay_CVs)==0){
                                    avg_CV <- NA
                                    count <- 0
                                }
                                else{
                                    avg_CV <- mean(individual_intra_assay_CVs, na.rm = TRUE)
                                }
 
                                if (current_LoMedHi=='Lo'){
                                    CV_results[CV_results$fragment_ion==current_ion, 'low_intra_CV'] <- round(avg_CV, digits=1)
                                }
                                else if(current_LoMedHi=='Med'){
                                    CV_results[CV_results$fragment_ion==current_ion, 'med_intra_CV'] <- round(avg_CV, digits=1)
                                }
                                else if(current_LoMedHi=='Hi'){
                                    CV_results[CV_results$fragment_ion==current_ion, 'high_intra_CV'] <- round(avg_CV, digits=1)
                                }
                            } # end current_LoMedHi
                        } # current_ion
                        # *** inter-assay CV ***
                        for (current_ion in ions) {
                            for (current_LoMedHi in LoMedHi) {
                                avg_inter_assay_CV <-0
                                individual_inter_assay_CVs <- c()
                                
                                avg_CV  <- 0
                                # for (current_day in days) {
                                for (current_rep in replicates) {           
                                    current_set <- fragment_ion_results[fragment_ion_results$fragment_ion==current_ion & fragment_ion_results$replicate==current_rep & fragment_ion_results$sample_group==current_LoMedHi, ]
                                    # remove rows with a value of NA for calculated_area_ratio
                                    current_set <- current_set[complete.cases(current_set[ , 'calculated_area_ratio' ]),]
                                    if (nrow(current_set) <= 1 ){
                                      percent_CV <- NA
                                    }
                                    else{
                                      percent_CV <- (sd(current_set$calculated_area_ratio))/(mean(current_set$calculated_area_ratio)) * 100
                                      individual_inter_assay_CVs <- c(individual_inter_assay_CVs, percent_CV)
                                    }
                                } # end current_rep
                                # } # end current_day
                                
                                if (length(individual_inter_assay_CVs)==0){
                                    avg_CV <- NA
                                    count <- 0
                                }
                                else{
                                    avg_CV <- mean(individual_inter_assay_CVs, na.rm = TRUE)
                                }
                                if (current_LoMedHi=='Lo'){
                                    CV_results[CV_results$fragment_ion==current_ion, 'low_inter_CV'] <- round(avg_CV, digits=1)
                                }
                                else if(current_LoMedHi=='Med'){
                                    CV_results[CV_results$fragment_ion==current_ion, 'med_inter_CV'] <- round(avg_CV, digits=1)
                                }
                                else if(current_LoMedHi=='Hi'){
                                    CV_results[CV_results$fragment_ion==current_ion, 'high_inter_CV'] <- round(avg_CV, digits=1)
                                }
                            } # end current_LoMedHi
                        } # current_ion

                        # *** END: inter-assay CV ***
                        # calculate total variability
                        CV_results[ , 'med_total_CV'] <- round(sqrt((CV_results[ , 'med_intra_CV'])*(CV_results[ , 'med_intra_CV']) + (CV_results[ , 'med_inter_CV'])*(CV_results[ , 'med_inter_CV'])), digits=1)
                        CV_results[ , 'high_total_CV'] <- round(sqrt((CV_results[ , 'high_intra_CV'])*(CV_results[ , 'high_intra_CV']) + (CV_results[ , 'high_inter_CV'])*(CV_results[ , 'high_inter_CV'])), digits=1)
                        CV_results[ , 'low_total_CV'] <- round(sqrt((CV_results[ , 'low_intra_CV'])*(CV_results[ , 'low_intra_CV']) + (CV_results[ , 'low_inter_CV'])*(CV_results[ , 'low_inter_CV'])), digits=1)

                        # determine counts
                        for (current_ion in ions) {
                            CV_results[CV_results$fragment_ion==current_ion, 'high_count'] <- nrow(fragment_ion_results[fragment_ion_results$sample_group=='Hi' & fragment_ion_results$fragment_ion==current_ion & !is.na(fragment_ion_results$calculated_area_ratio), ] )
                            CV_results[CV_results$fragment_ion==current_ion, 'med_count'] <- nrow(fragment_ion_results[fragment_ion_results$sample_group=='Med' & fragment_ion_results$fragment_ion==current_ion & !is.na(fragment_ion_results$calculated_area_ratio), ] )
                            CV_results[CV_results$fragment_ion==current_ion, 'low_count'] <- nrow(fragment_ion_results[fragment_ion_results$sample_group=='Lo' & fragment_ion_results$fragment_ion==current_ion & !is.na(fragment_ion_results$calculated_area_ratio), ] )
                        }

                        ions_to_plot <- c()

                        # determine fragment ions to plot
                        if (length(ions) <= 4 ) {
                            ions_to_plot <- ions
                        } else {
                        results_to_plot <- CV_results[CV_results$fragment_ion!='all' & !is.na(CV_results$low_total_CV) & !is.na(CV_results$med_total_CV) & !is.na(CV_results$high_total_CV) , ]
                        # new sort to get Top 3 plots
                        results_to_plot <- results_to_plot[order(results_to_plot$med_total_CV, results_to_plot$low_total_CV, results_to_plot$high_total_CV), ]
                        three_lowest_med_total_CV <- head(results_to_plot, 3)
                        three_lowest_ions <- as.character(three_lowest_med_total_CV[ , 'fragment_ion'])
                        ions_to_plot  <- c(three_lowest_ions, 'all')
                        }

                        for (current_plot_ion in ions_to_plot ) {
                            plot_fragment_ion_results <- fragment_ion_results[!is.na(fragment_ion_results$calculated_area_ratio), ]
                            plot_fragment_ion_results <- plot_fragment_ion_results[plot_fragment_ion_results$fragment_ion == current_plot_ion, ]
                            plot_days <- sort(unique(plot_fragment_ion_results[ , 'day']))
                            # capture the situation where no points are observed at specific day.
                            daysTmp <- setdiff(days,plot_days)
                            if (curve_type=='reverse') {
                                if (length(daysTmp) > 0) {
                                    errorReason <- paste("Warning: for fragment ion ", current_plot_ion, ", there is no point on day ",  paste(daysTmp, collapse = ', '), sep="")
                                    errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(isotope_label_types, collapse = '|'), input_precursor_charge, '', '', '', '', '', '', '', '', sep='\t')
                                    cat(errorInfor)
                                    cat('\n')
                                }
                            }
                            # do not make plots for fragment ions with no data
                            if (nrow(plot_fragment_ion_results) != 0) {
                                # make QC plot for current ion
                                plot_QC(plot_fragment_ion_results, input_peptide_sequence, current_plot_ion, plot_days)
                            }
                        }
                        dev.off()
                        # output to files
                        #write.csv(CV_results, file=paste(plot_output_dir, "\\", input_peptide_sequence, "_", input_precursor_charge, "_", input_protein_name, "_", curve_type ,"_CV_results_", trunc(as.numeric(now)), ".csv", sep=""))
                        write.csv(CV_results, file=paste(plot_output_dir, "\\", input_peptide_sequence, "_", input_precursor_charge, "_", curve_type ,"_CV_results_", trunc(as.numeric(now)), ".csv", sep=""))
                        # Top 3 plots were selected based on med_total_CV, low_total_CV and high_total_CV.
                        # med_total_CV, low_total_CV and high_total_CV of the will be used to evaluate the quality.
                        CV_results_sub <- subset(CV_results, select = c(fragment_ion, low_total_CV, med_total_CV, high_total_CV))
                        max_total_CV <- max(CV_results_sub[CV_results_sub$fragment_ion == "all", ][,c(2,3,4)])
                        if (curve_type=='reverse') {
                            if (max_total_CV > cv_threshold) {
                                errorReason <- "Warning: the total coefficient of variation of all the fragment ions is large."
                                errorInfor <- paste(SkyDocumentName, errorReason, input_protein_name, input_peptide_sequence, paste(isotope_label_types, collapse = '|'), input_precursor_charge, '', '', '', '', '', '', '', '', sep='\t')
                                cat(errorInfor)
                                cat('\n')
                            }
                        }
                    }
                }
            }
        } 
    }
    write.table(logdf, file=log_filename, row.names=FALSE, col.names=TRUE, quote=FALSE, sep='\t')
}