from qcAnalysis import *

inf = "Base_RAS_6plex_breast_tumor_frozen_repeatability_for_upload.sky"

internal_standard = detectIS(inf)

print internal_standard