from qcAnalysis import *
import os

SkylineCmdBinary = 'C:\\Program Files\\Skyline\\SkylineCmd.exe'
reportName = 'experiment2'
skyrTemp = 'D:\\Skyline_analysis\\qcAssayPortal\\qcAssayPortal\\src\\qcAssayPortal\\skyrTemps\\experiment2.skyr'
outf1 = 'error_report.tsv'
outf2 = 'normal_report.tsv'
#outfLog = open('skylineCmd.log', 'a')
skylineCmdLog = 'skylineCmdRun.log'
experiment_type = 'exp2'

skyTsvDirList = []
fileNameList = []
input_file_sky = 'D:\\Skyline_analysis\\qcAssayPortal\\data\\JHU_Pandey-EcoliLysate_LumosOrbitrap_directPRM\\exp2.2018-10-10_13-31-48\\skyFiles.tmp\\JPT_Repeatability_07082016-ver3-noALP_LMT.sky'
output_file = 'D:\\Skyline_analysis\\qcAssayPortal\\data\\JHU_Pandey-EcoliLysate_LumosOrbitrap_directPRM\\exp2.2018-10-10_13-31-48\\skyFiles.tmp\\JPT_Repeatability_07082016-ver3-noALP_LMT.tsv'
#print '"%s" --timestamp --in=%s --report-file=%s --report-format=TSV --report-name=%s --report-add=%s --report-conflict-resolution=overwrite --report-invariant'%(SkylineCmdBinary, input_file_sky, output_file, reportName, skyrTemp)
#print >> outfLog, 'Process %s'%(input_file_sky)
#os.system('"%s" --timestamp --in=%s --report-file=%s --report-format=TSV --report-name=%s --report-add=%s --report-conflict-resolution=overwrite --report-invariant >> %s'%(SkylineCmdBinary, input_file_sky, output_file, reportName, skyrTemp, skylineCmdLog))

skyTsvDirList.append(output_file)
fileNameList.append("JPT_Repeatability_07082016-ver3-noALP_LMT.sky.zip")
errorDf, normalDf = qcAnalysisGlobal(experiment_type, skyTsvDirList, fileNameList)
errorDf.to_csv(outf1, sep='\t', header=True, index=False)
normalDf.to_csv(outf2, sep='\t', header=True, index=False)
print "Done"